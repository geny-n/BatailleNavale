# batailel_naval
 1.	jeu de bataille navale ( 3 bateaux, 1 à 2 cases,  1 à 3 cases, 1 à 4 cases), un bateau coule dès qu'on le touche, on peut sauvegarder la partie et la reprendre, jeu avec l'ordi ou en deux joueurs. 

 Tous les jeux sont à réaliser avec : 
-	des tableaux en matrice 8*8
-	des procédures et fonctions 
-	des fichiers pour sauvegarder
-	une console sans graphique avec des choix

Pour aller plus loin : 
-	librairie graphique conio.h / conio.c
-	Librairie graphique la SDL

